package com.example.enrollment.controller;

import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/students")
public class StudentController {
    // Add your REST endpoints here
}