package com.example.enrollment;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class StudentControllerTest {
    @Test
    void contextLoads() {
    }
}